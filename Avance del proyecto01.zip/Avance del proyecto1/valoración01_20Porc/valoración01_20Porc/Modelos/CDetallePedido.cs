﻿namespace valoracion01_20Porc.Modelos
{
    // Modelo de Apoyo
    public class CDetallePedido
    {
        public string Producto { get; set; } = string.Empty;
        public double Precio { get; set; }
    }
}