﻿using System;

namespace valoracion01_20Porc.Modelos
{
    public class CPedido
    {
        public int NroPedido { get; set; }                  // Dato 1
        public string Cliente { get; set; } = string.Empty; // Dato 2
        public CDetallePedido Detalle { get; set; } = new CDetallePedido(); // Dato 3 (Modelo de apoyo)
        public string MetodoPago { get; set; } = "EFECTIVO"; // Dato 4 (EFECTIVO o QR)
        public DateTime Hora { get; set; } = DateTime.Now;   // Dato 5
    }
}
