using Microsoft.AspNetCore.Components.Web;
using Microsoft.AspNetCore.Components.WebAssembly.Hosting;
using valoracion01_20Porc;
using valoración01_20Porc;
using valoracion01_20Porc.Servicios;

// 1. PRIMERO: Se crea el constructor (builder)
var builder = WebAssemblyHostBuilder.CreateDefault(args);

builder.RootComponents.Add<App>("#app");
builder.RootComponents.Add<HeadOutlet>("head::after");

// 2. SEGUNDO: Se registran todos los servicios usando el builder ya creado
builder.Services.AddScoped(sp => new HttpClient { BaseAddress = new Uri(builder.HostEnvironment.BaseAddress) });

// AQUÍ REGISTRAMOS TU SERVICIO CENTRAL DE VENTAS
builder.Services.AddSingleton<ServicioVentas>();

// 3. TERCERO: Se compila y ejecuta la aplicación
await builder.Build().RunAsync();