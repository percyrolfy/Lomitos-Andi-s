﻿using System.Collections.Generic;
using System.Linq;
using valoracion01_20Porc.Modelos;

namespace valoracion01_20Porc.Servicios
{
    public class ServicioVentas
    {
        public List<CDetallePedido> MenuComida { get; private set; } = new List<CDetallePedido>
        {
            new CDetallePedido { Producto = "Hamburqueza Simple", Precio = 15.00 },
            new CDetallePedido { Producto = "Hamburguesa Clásica con Papas", Precio = 22.00 },
            new CDetallePedido { Producto = "Hamburguesa Doble Carne y Papas", Precio = 27.00 },
            new CDetallePedido { Producto = "Hamburqueza Tocino + Huevo + Papas", Precio = 30.00 },
            new CDetallePedido { Producto = "Hamburguesa Doble Carne + Tocino + Huevo + Papas", Precio = 35.00 },
            new CDetallePedido { Producto = "Lomito Simple", Precio = 16.00 },
            new CDetallePedido { Producto = "Lomito Clásico con Papas", Precio = 23.00 },
            new CDetallePedido { Producto = "LOmito Doble Carne y Papas", Precio = 28.00 },
            new CDetallePedido { Producto = "Lomito Tocino + Huevo + Papas", Precio = 31.00 },
            new CDetallePedido { Producto = "Lomito Doble Carne + Tocino + Huevo + Papas", Precio = 36.00 },
        };

        // Lista de pedidos confirmados finales
        public List<CPedido> ListaPedidos { get; private set; } = new List<CPedido>();

        // OBJETO TEMPORAL: El pedido que se está armando antes de confirmarse en Weather.razor
        public CPedido PedidoActual { get; set; } = new CPedido();

        private int contadorPedidos = 1;

        public void ConfirmarPedidoActual()
        {
            PedidoActual.NroPedido = contadorPedidos++;
            PedidoActual.Hora = System.DateTime.Now;
            ListaPedidos.Add(PedidoActual);

            // Limpiamos el carrito para el siguiente cliente
            PedidoActual = new CPedido();
        }
    }
}